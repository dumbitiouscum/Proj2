#!/bin/bash

# import utils
source scripts/envVar1.sh

ORG=$1

setGlobals $ORG